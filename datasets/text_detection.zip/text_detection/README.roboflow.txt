
text detection - v1 2022-05-17 5:07pm
==============================

This dataset was exported via roboflow.ai on May 17, 2022 at 11:38 AM GMT

It includes 400 images.
Text are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


